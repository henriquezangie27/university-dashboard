-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-06-2021 a las 02:44:46
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bibliotecanph`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_area_estudio`
--

CREATE TABLE `t_area_estudio` (
  `id_area` int(10) NOT NULL,
  `area_estudio` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_area_estudio`
--

INSERT INTO `t_area_estudio` (`id_area`, `area_estudio`, `titulo_libro`) VALUES
(1, 'general', 'Caracol');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_autor`
--

CREATE TABLE `t_autor` (
  `id_autor` int(10) NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `autor` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_autor`
--

INSERT INTO `t_autor` (`id_autor`, `titulo_libro`, `autor`) VALUES
(1, 'Caracol', 'laura cambra');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_biblioteca`
--

CREATE TABLE `t_biblioteca` (
  `id_biblioteca` int(10) NOT NULL,
  `biblioteca` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `director` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `subdirector` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sucursal` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_biblioteca`
--

INSERT INTO `t_biblioteca` (`id_biblioteca`, `biblioteca`, `director`, `subdirector`, `sucursal`, `direccion`, `telefono`) VALUES
(1, 'paul harris', 'angie henriquez', 'milagros brito', 'california', 'california', 2127895646);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_editorial`
--

CREATE TABLE `t_editorial` (
  `id_editorial` int(10) NOT NULL,
  `editorial` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` int(20) DEFAULT NULL,
  `nombre_editorial` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pais` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `autor` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_editorial`
--

INSERT INTO `t_editorial` (`id_editorial`, `editorial`, `direccion`, `telefono`, `nombre_editorial`, `pais`, `autor`) VALUES
(1, 'santillana', 'romulo gallegos', 2127895647, 'santillana', 'venezuela', 'laura cambra');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_estado`
--

CREATE TABLE `t_estado` (
  `id_estado` int(10) NOT NULL,
  `descripcion_estado` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_estado`
--

INSERT INTO `t_estado` (`id_estado`, `descripcion_estado`, `titulo_libro`) VALUES
(1, 'nose', 'Caracol');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_libro`
--

CREATE TABLE `t_libro` (
  `id_libro` int(10) NOT NULL,
  `usuarios_id` int(10) NOT NULL,
  `ISBN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `autor` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nombre_editorial` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pais` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `area_estudio` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `idioma` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_publicacion` year(4) DEFAULT NULL,
  `tomo_libro` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_libro`
--

INSERT INTO `t_libro` (`id_libro`, `usuarios_id`, `ISBN`, `titulo_libro`, `autor`, `nombre_editorial`, `pais`, `tipo_libro`, `area_estudio`, `idioma`, `fecha_publicacion`, `tomo_libro`) VALUES
(1, 1, '980275374', 'Caracol', 'laura cambra', 'santillana', 'venezuela', 'diccionario', 'general', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_libro_autor`
--

CREATE TABLE `t_libro_autor` (
  `autor_id` int(10) NOT NULL,
  `autor` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `libro_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_libro_autor`
--

INSERT INTO `t_libro_autor` (`autor_id`, `autor`, `titulo_libro`, `libro_id`) VALUES
(1, 'laura cambra', 'Caracol', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_pais`
--

CREATE TABLE `t_pais` (
  `id_pais` int(10) NOT NULL,
  `pais` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_pais`
--

INSERT INTO `t_pais` (`id_pais`, `pais`, `titulo_libro`) VALUES
(1, 'venezuela', 'Caracol');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_prestamo`
--

CREATE TABLE `t_prestamo` (
  `id_prestamo` int(10) NOT NULL,
  `prestamo` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `usuarios_id` int(10) NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_prestamo` date NOT NULL,
  `fecha_devolucion` date NOT NULL,
  `hora` time NOT NULL,
  `tipo_prestamo` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `descrpcion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `estado_descripcion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `usuario_tipo` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_prestamo`
--

INSERT INTO `t_prestamo` (`id_prestamo`, `prestamo`, `usuarios_id`, `titulo_libro`, `fecha_prestamo`, `fecha_devolucion`, `hora`, `tipo_prestamo`, `descrpcion`, `estado_descripcion`, `usuario_tipo`) VALUES
(1, 'prueba', 1, 'Caracol', '2021-06-05', '2021-06-05', '12:00:00', 'interno', 'test', 'nose', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_sucursal`
--

CREATE TABLE `t_sucursal` (
  `id_sucursal` int(10) NOT NULL,
  `sucursal` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `usuarios_id` int(10) NOT NULL,
  `titulo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_sucursal`
--

INSERT INTO `t_sucursal` (`id_sucursal`, `sucursal`, `usuarios_id`, `titulo_libro`, `direccion`) VALUES
(1, 'california', 1, 'Caracol', 'test');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_tipo_libro`
--

CREATE TABLE `t_tipo_libro` (
  `id_tipo_libro` int(10) NOT NULL,
  `tipo_libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_tipo_libro`
--

INSERT INTO `t_tipo_libro` (`id_tipo_libro`, `tipo_libro`) VALUES
(1, 'diccionario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_tipo_prestamo`
--

CREATE TABLE `t_tipo_prestamo` (
  `id_t_prestamo` int(10) NOT NULL,
  `tipo_prestamo` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_tipo_prestamo`
--

INSERT INTO `t_tipo_prestamo` (`id_t_prestamo`, `tipo_prestamo`) VALUES
(1, 'interno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_usuarios`
--

CREATE TABLE `t_usuarios` (
  `id_usuarios` int(10) NOT NULL,
  `nombre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Doc_identidad` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `cedula` int(50) NOT NULL,
  `telefono` int(50) NOT NULL,
  `direccion` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `clave_acceso` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_usuario` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `t_usuarios`
--

INSERT INTO `t_usuarios` (`id_usuarios`, `nombre`, `apellido`, `Doc_identidad`, `cedula`, `telefono`, `direccion`, `clave_acceso`, `estado`, `tipo_usuario`) VALUES
(1, 'Luis', 'Meza', 'v', 23456789, 412808999, 'petare', NULL, 'inactivo', 'Administrador'),
(2, 'pedro', 'moreno', 'V', 12345678, 424600998, 'catia', NULL, 'activo', 'DOCENTE'),
(3, 'juan', 'bautista', 'v', 3456789, 412808999, 'la castellana', NULL, 'activo', 'estudiante'),
(4, 'jesus', 'perez', 'v', 4567890, 2127895646, 'guarenas', NULL, 'inactivo', 'usuario');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `t_area_estudio`
--
ALTER TABLE `t_area_estudio`
  ADD PRIMARY KEY (`id_area`),
  ADD UNIQUE KEY `area_estudio` (`area_estudio`),
  ADD KEY `titulo_libro` (`titulo_libro`);

--
-- Indices de la tabla `t_autor`
--
ALTER TABLE `t_autor`
  ADD PRIMARY KEY (`id_autor`),
  ADD UNIQUE KEY `autor` (`autor`),
  ADD KEY `titulo_libro` (`titulo_libro`);

--
-- Indices de la tabla `t_biblioteca`
--
ALTER TABLE `t_biblioteca`
  ADD PRIMARY KEY (`id_biblioteca`),
  ADD KEY `sucursal` (`sucursal`);

--
-- Indices de la tabla `t_editorial`
--
ALTER TABLE `t_editorial`
  ADD PRIMARY KEY (`id_editorial`),
  ADD UNIQUE KEY `editorial` (`editorial`),
  ADD KEY `pais` (`pais`),
  ADD KEY `autor` (`autor`);

--
-- Indices de la tabla `t_estado`
--
ALTER TABLE `t_estado`
  ADD PRIMARY KEY (`id_estado`),
  ADD KEY `titulo_libro` (`titulo_libro`),
  ADD KEY `descripcion_estado` (`descripcion_estado`);

--
-- Indices de la tabla `t_libro`
--
ALTER TABLE `t_libro`
  ADD PRIMARY KEY (`id_libro`),
  ADD UNIQUE KEY `titulo_libro` (`titulo_libro`),
  ADD KEY `usuarios_id` (`usuarios_id`),
  ADD KEY `autor` (`autor`),
  ADD KEY `nombre_editorial` (`nombre_editorial`),
  ADD KEY `pais` (`pais`),
  ADD KEY `tipo_libro` (`tipo_libro`),
  ADD KEY `area_estudio` (`area_estudio`);

--
-- Indices de la tabla `t_libro_autor`
--
ALTER TABLE `t_libro_autor`
  ADD PRIMARY KEY (`autor_id`),
  ADD KEY `autor` (`autor`),
  ADD KEY `titulo_libro` (`titulo_libro`),
  ADD KEY `libro_id` (`libro_id`);

--
-- Indices de la tabla `t_pais`
--
ALTER TABLE `t_pais`
  ADD PRIMARY KEY (`id_pais`),
  ADD UNIQUE KEY `pais` (`pais`),
  ADD KEY `titulo_libro` (`titulo_libro`);

--
-- Indices de la tabla `t_prestamo`
--
ALTER TABLE `t_prestamo`
  ADD PRIMARY KEY (`id_prestamo`),
  ADD KEY `usuarios_id` (`usuarios_id`),
  ADD KEY `titulo_libro` (`titulo_libro`),
  ADD KEY `tipo_prestamo` (`tipo_prestamo`),
  ADD KEY `usuario_tipo` (`usuario_tipo`),
  ADD KEY `t_prestamo_ibfk_4` (`estado_descripcion`);

--
-- Indices de la tabla `t_sucursal`
--
ALTER TABLE `t_sucursal`
  ADD PRIMARY KEY (`id_sucursal`),
  ADD UNIQUE KEY `sucursal` (`sucursal`),
  ADD KEY `usuarios_id` (`usuarios_id`),
  ADD KEY `titulo_libro` (`titulo_libro`);

--
-- Indices de la tabla `t_tipo_libro`
--
ALTER TABLE `t_tipo_libro`
  ADD PRIMARY KEY (`id_tipo_libro`),
  ADD UNIQUE KEY `tipo_libro` (`tipo_libro`);

--
-- Indices de la tabla `t_tipo_prestamo`
--
ALTER TABLE `t_tipo_prestamo`
  ADD PRIMARY KEY (`id_t_prestamo`),
  ADD UNIQUE KEY `tipo_prestamo` (`tipo_prestamo`);

--
-- Indices de la tabla `t_usuarios`
--
ALTER TABLE `t_usuarios`
  ADD PRIMARY KEY (`id_usuarios`),
  ADD UNIQUE KEY `tipo_usuario` (`tipo_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `t_area_estudio`
--
ALTER TABLE `t_area_estudio`
  MODIFY `id_area` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_autor`
--
ALTER TABLE `t_autor`
  MODIFY `id_autor` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_biblioteca`
--
ALTER TABLE `t_biblioteca`
  MODIFY `id_biblioteca` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_editorial`
--
ALTER TABLE `t_editorial`
  MODIFY `id_editorial` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_estado`
--
ALTER TABLE `t_estado`
  MODIFY `id_estado` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_libro`
--
ALTER TABLE `t_libro`
  MODIFY `id_libro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_libro_autor`
--
ALTER TABLE `t_libro_autor`
  MODIFY `autor_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_pais`
--
ALTER TABLE `t_pais`
  MODIFY `id_pais` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_prestamo`
--
ALTER TABLE `t_prestamo`
  MODIFY `id_prestamo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_sucursal`
--
ALTER TABLE `t_sucursal`
  MODIFY `id_sucursal` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_tipo_libro`
--
ALTER TABLE `t_tipo_libro`
  MODIFY `id_tipo_libro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_tipo_prestamo`
--
ALTER TABLE `t_tipo_prestamo`
  MODIFY `id_t_prestamo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `t_usuarios`
--
ALTER TABLE `t_usuarios`
  MODIFY `id_usuarios` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `t_area_estudio`
--
ALTER TABLE `t_area_estudio`
  ADD CONSTRAINT `t_area_estudio_ibfk_1` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`),
  ADD CONSTRAINT `t_area_estudio_ibfk_2` FOREIGN KEY (`area_estudio`) REFERENCES `t_libro` (`area_estudio`);

--
-- Filtros para la tabla `t_autor`
--
ALTER TABLE `t_autor`
  ADD CONSTRAINT `t_autor_ibfk_1` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`),
  ADD CONSTRAINT `t_autor_ibfk_2` FOREIGN KEY (`autor`) REFERENCES `t_libro` (`autor`);

--
-- Filtros para la tabla `t_biblioteca`
--
ALTER TABLE `t_biblioteca`
  ADD CONSTRAINT `t_biblioteca_ibfk_1` FOREIGN KEY (`sucursal`) REFERENCES `t_sucursal` (`sucursal`);

--
-- Filtros para la tabla `t_editorial`
--
ALTER TABLE `t_editorial`
  ADD CONSTRAINT `t_editorial_ibfk_2` FOREIGN KEY (`autor`) REFERENCES `t_autor` (`autor`),
  ADD CONSTRAINT `t_editorial_ibfk_3` FOREIGN KEY (`editorial`) REFERENCES `t_libro` (`nombre_editorial`);

--
-- Filtros para la tabla `t_estado`
--
ALTER TABLE `t_estado`
  ADD CONSTRAINT `t_estado_ibfk_1` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`),
  ADD CONSTRAINT `t_estado_ibfk_2` FOREIGN KEY (`descripcion_estado`) REFERENCES `t_prestamo` (`estado_descripcion`);

--
-- Filtros para la tabla `t_libro`
--
ALTER TABLE `t_libro`
  ADD CONSTRAINT `t_libro_ibfk_1` FOREIGN KEY (`usuarios_id`) REFERENCES `t_usuarios` (`id_usuarios`),
  ADD CONSTRAINT `t_libro_ibfk_7` FOREIGN KEY (`titulo_libro`) REFERENCES `t_prestamo` (`titulo_libro`);

--
-- Filtros para la tabla `t_libro_autor`
--
ALTER TABLE `t_libro_autor`
  ADD CONSTRAINT `t_libro_autor_ibfk_1` FOREIGN KEY (`libro_id`) REFERENCES `t_libro` (`id_libro`),
  ADD CONSTRAINT `t_libro_autor_ibfk_2` FOREIGN KEY (`autor`) REFERENCES `t_autor` (`autor`),
  ADD CONSTRAINT `t_libro_autor_ibfk_4` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`);

--
-- Filtros para la tabla `t_pais`
--
ALTER TABLE `t_pais`
  ADD CONSTRAINT `t_pais_ibfk_1` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`),
  ADD CONSTRAINT `t_pais_ibfk_2` FOREIGN KEY (`pais`) REFERENCES `t_libro` (`pais`);

--
-- Filtros para la tabla `t_prestamo`
--
ALTER TABLE `t_prestamo`
  ADD CONSTRAINT `t_prestamo_ibfk_1` FOREIGN KEY (`usuarios_id`) REFERENCES `t_usuarios` (`id_usuarios`),
  ADD CONSTRAINT `t_prestamo_ibfk_5` FOREIGN KEY (`usuario_tipo`) REFERENCES `t_usuarios` (`tipo_usuario`);

--
-- Filtros para la tabla `t_sucursal`
--
ALTER TABLE `t_sucursal`
  ADD CONSTRAINT `t_sucursal_ibfk_1` FOREIGN KEY (`usuarios_id`) REFERENCES `t_usuarios` (`id_usuarios`),
  ADD CONSTRAINT `t_sucursal_ibfk_2` FOREIGN KEY (`titulo_libro`) REFERENCES `t_libro` (`titulo_libro`);

--
-- Filtros para la tabla `t_tipo_libro`
--
ALTER TABLE `t_tipo_libro`
  ADD CONSTRAINT `t_tipo_libro_ibfk_1` FOREIGN KEY (`tipo_libro`) REFERENCES `t_libro` (`tipo_libro`);

--
-- Filtros para la tabla `t_tipo_prestamo`
--
ALTER TABLE `t_tipo_prestamo`
  ADD CONSTRAINT `t_tipo_prestamo_ibfk_1` FOREIGN KEY (`tipo_prestamo`) REFERENCES `t_prestamo` (`tipo_prestamo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
