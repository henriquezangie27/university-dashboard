#Librerias utilizadas
from flask import Flask, request, render_template, redirect, url_for, flash, session, logging, escape
import pymysql.cursors

#Objeto de de la Libreria Flask
app = Flask(__name__)

# Conexion a pymysql
# Connect to the database
connection = pymysql.connect(host='localhost',
                             user='root',
                             port=3306,
                             password='ADMIN',
                             database='biblioteca2',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor
                             )

# settings
app.secret_key = 'mysecretkey'

# Ruta predeterminada para acceder a la página de inicio de sesión 
@app.route('/', methods=['POST' , 'GET'])
def login():
    cursor = connection.cursor()
    try:
          cursor.execute(''' SELECT * FROM t_login ''')
          data = cursor.fetchall()
    finally:

        #flash('Debes registrarte')
        #return render_template('/Home', login=data)
        return render_template('login.html', login=data)

#@app.route('/Registro', methods=['POST', 'GET'])
#def registro():
#    cursor = connection.cursor()
#    if request.method == 'POST':
#        login = request.form['login']
#        password = request.form['password']
#        correo = request.form['correo']
#        try:
#            cursor.execute('''INSERT INTO t_login (login, password, correo)
#            VALUES (%s, %s, %s)''',
#                           (login, password, correo))
#            connection.commit()
#        finally:
#            flash('Has sido registrado,presiona Volver para regresar al Inicio ')
#    return render_template('registro-login.html')

@app.route('/Home')
def home():
    return render_template('home.html')


@app.route('/usuarios')
def usuarios():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_usuarios''')
        data = cursor.fetchall()
    finally:
        return render_template('user.html', t_usuarios = data) 
        #return redirect(url_for('usuarios'))

@app.route('/add_user', methods=['POST', 'GET'])
def add_user():
    cursor = connection.cursor()
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        Doc_identidad = request.form['Doc_identidad']
        cedula = request.form['cedula']
        telefono = request.form['telefono']
        direccion = request.form['direccion']
        estado = request.form['estado']
        tipo_usuario = request.form['tipo_usuario']
        try:
            cursor.execute('''INSERT INTO t_usuarios (nombre, apellido, Doc_identidad, cedula, telefono, direccion, estado, tipo_usuario)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)''',
            (nombre, apellido, Doc_identidad, cedula, telefono, direccion, estado, tipo_usuario))
            connection.commit()
        finally:
            flash('Usuario agregado')
    return render_template ('add_user.html')



@ app.route('/edit/<id_usuarios>')
def get_user(id_usuarios):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_usuarios WHERE id_usuarios = '"+id_usuarios+"' ")
        data = cursor.fetchall()
    finally:
        return render_template ('edit_user.html', user=data[0])
        #return redirect(url_for('usuarios', t_usuarios=data))

@app.route('/update/<id_usuarios>', methods=['POST' , 'GET'] )
def update(id_usuarios):
    cursor = connection.cursor()
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        Doc_identidad = request.form['Doc_identidad']
        cedula = request.form['cedula']
        telefono = request.form['telefono']
        direccion = request.form['direccion']
        estado = request.form['estado']
        tipo_usuario = request.form['tipo_usuario']
        try:
            cursor.execute(" UPDATE t_usuarios SET nombre = %s, apellido = %s, Doc_identidad = %s, cedula = %s, telefono = %s,  direccion = %s, estado = %s, tipo_usuario = %s  WHERE id_usuarios = '"+id_usuarios+"' ",
                           (nombre, apellido, Doc_identidad, cedula, telefono, direccion, estado, tipo_usuario))
            connection.commit()

        finally:
            flash('Usuario Actualizado')
        return redirect (url_for('usuarios'))


@ app.route('/delete/<string:id_usuarios>')
def delete(id_usuarios):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_usuarios WHERE id_usuarios = '"+id_usuarios+"' "
    try:
        #cursor.execute('''DELETE FROM t_usuarios WHERE id_usuarios = '%s' ''')
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Usuario Borrado')
    return redirect(url_for('usuarios'))

@app.route('/libros')
def libro():
        cursor = connection.cursor()
        try:
            cursor.execute(''' SELECT * FROM t_libro''')
            datalibro = cursor.fetchall()
        finally:
             return render_template('libro.html', t_libro = datalibro) 

@app.route('/add_libro', methods=['POST', 'GET'])
def Libro():
    cursor = connection.cursor()
    if request.method == 'POST':
        ISBN = request.form['ISBN']
        titulo_libro = request.form['titulo_libro']
        autor = request.form['autor']
        autoruno = request.form['autoruno']
        autordos = request.form['autordos']
        autortres = request.form['autortres']
        nombre_editorial = request.form['nombre_editorial']
        pais = request.form['pais']
        tipo_libro = request.form['tipo_libro']
        area_estudio = request.form['area_estudio']
        idioma = request.form['idioma']
        fecha_publicacion = request.form['fecha_publicacion']
        tomo_libro = request.form['tomo_libro']
        try:
            cursor.execute('''INSERT INTO t_libro (ISBN, titulo_libro, autor, autoruno, autordos, autortres, nombre_editorial, pais, tipo_libro, area_estudio, idioma, fecha_publicacion, tomo_libro)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)''',
            (ISBN, titulo_libro, autor, autoruno, autordos, autortres, nombre_editorial, pais, tipo_libro, area_estudio, idioma,fecha_publicacion,tomo_libro ))
            connection.commit()
        finally:
            flash('Libro Agregado')
    return render_template ('add_libro.html')


@ app.route('/edit_libro/<id_libro>')
def get_libro(id_libro):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_libro WHERE id_libro = '"+id_libro+"' ")
        datalibro = cursor.fetchall()
    finally:
        return render_template ('edit_libro.html', libro=datalibro[0])

@app.route('/update_libro/<id_libro>', methods=['POST' , 'GET'] )
def update_libro(id_libro):
    cursor = connection.cursor()
    if request.method == 'POST':
        ISBN = request.form['ISBN']
        titulo_libro = request.form['titulo_libro']
        autor = request.form['autor']
        autoruno = request.form['autoruno']
        autordos = request.form['autordos']
        autortres = request.form['autortres']
        nombre_editorial = request.form['nombre_editorial']
        pais = request.form['pais']
        tipo_libro = request.form['tipo_libro']
        area_estudio = request.form['area_estudio']
        idioma = request.form['idioma']
        fecha_publicacion = request.form['fecha_publicacion']
        tomo_libro = request.form['tomo_libro']
        try:
            cursor.execute(" UPDATE t_libro SET ISBN = %s, titulo_libro = %s, autor = %s, autoruno = %s, autordos = %s, autortres = %s, nombre_editorial = %s, pais = %s,  tipo_libro = %s, area_estudio = %s, idioma = %s, fecha_publicacion = %s, tomo_libro = %s  WHERE id_libro = '"+id_libro+"' ",
                           (ISBN, titulo_libro, autor, autoruno, autordos, autortres, nombre_editorial, pais, tipo_libro, area_estudio, idioma,fecha_publicacion,tomo_libro ))
            connection.commit() 

        finally:
            flash('Libro Actualizado')
        return redirect (url_for('libro'))

@ app.route('/delete_libro/<string:id_libro>')
def delete_libro(id_libro):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_libro WHERE id_libro = '"+id_libro+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Libro Borrado')
    return redirect(url_for('libro'))


@app.route('/prestamo')
def prestamo():
        cursor = connection.cursor()
        try:
            cursor.execute(''' SELECT * FROM t_prestamo ''')
            datap = cursor.fetchall()
        finally:
             return render_template('prestamo.html', t_prestamo = datap) 

@app.route('/add_prestamo', methods=['POST', 'GET'])
def prestamos():
    cursor = connection.cursor()
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        cedula = request.form['cedula']
        titulo_libro = request.form['titulo_libro']
        fecha_prestamo = request.form['fecha_prestamo']
        fecha_devolucion = request.form['fecha_devolucion']
        hora = request.form['hora']
        tipo_prestamo = request.form['tipo_prestamo']
        descripcion = request.form['descripcion']
        estado_descripcion = request.form['estado_descripcion']
        usuario_tipo = request.form['usuario_tipo']
        try:
            cursor.execute('''INSERT INTO t_prestamo (nombre, apellido, cedula, titulo_libro, fecha_prestamo, fecha_devolucion, hora, tipo_prestamo, descripcion, estado_descripcion, usuario_tipo)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)''',
            (nombre, apellido, cedula, titulo_libro, fecha_prestamo, fecha_devolucion, hora, tipo_prestamo, descripcion, estado_descripcion, usuario_tipo ))
            connection.commit()
        finally:
            flash('Prestamo Registrado')
    return render_template ('add_prestamo.html')

@ app.route('/devolucion/<id_prestamo>')
def get_prestamo(id_prestamo):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_prestamo WHERE id_prestamo = '"+id_prestamo+"' ")
        datap = cursor.fetchall()
    finally:
        return render_template ('edit_prestamo.html', prestamo=datap[0])

@app.route('/update_prestamo/<id_prestamo>', methods=['POST' , 'GET'] )
def update_prestamo(id_prestamo):
    cursor = connection.cursor()
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        cedula = request.form['cedula']
        titulo_libro = request.form['titulo_libro']
        fecha_prestamo = request.form['fecha_prestamo']
        fecha_devolucion = request.form['fecha_devolucion']
        hora = request.form['hora']
        tipo_prestamo = request.form['tipo_prestamo']
        descripcion = request.form['descripcion']
        estado_descripcion = request.form['estado_descripcion']
        usuario_tipo = request.form['usuario_tipo']
        try:
            cursor.execute(" UPDATE t_prestamo SET nombre = %s, apellido = %s, cedula = %s, titulo_libro = %s, fecha_prestamo = %s, fecha_devolucion = %s, hora = %s,  tipo_prestamo = %s, descripcion = %s, estado_descripcion = %s, usuario_tipo = %s WHERE id_prestamo = '"+id_prestamo+"' ",
                           (nombre, apellido, cedula, titulo_libro, fecha_prestamo, fecha_devolucion, hora, tipo_prestamo, descripcion, estado_descripcion,usuario_tipo ))
            connection.commit()
        finally:
            flash('Prestamo Actualizado')
        return redirect (url_for('prestamo'))

@ app.route('/delete_prestamo/<string:id_prestamo>')
def delete_prestamo(id_prestamo):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_prestamo WHERE id_prestamo = '"+id_prestamo+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Prestamo Borrado')
    return redirect(url_for('prestamo'))


@app.route('/biblioteca')
def biblioteca():
    return render_template('biblioteca.html')

@ app.route('/editorial')
def editorial():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_editorial''')
        dataedit = cursor.fetchall()
    finally:
        return render_template('editorial.html', t_editorial = dataedit) 

@app.route('/add_editorial', methods=['POST', 'GET'])
def add_editorial():
    cursor = connection.cursor()
    if request.method == 'POST':
        editorial = request.form['editorial']
        direccion = request.form['direccion']
        telefono = request.form['telefono']
        pais = request.form['pais']
        autor = request.form['autor']
        try:
            cursor.execute('''INSERT INTO t_editorial (editorial, direccion, telefono, pais, autor)
            VALUES (%s, %s, %s, %s, %s)''',
            (editorial, direccion, telefono, pais, autor))
            connection.commit()
        finally:
            flash('Editorial Registrada')
            return redirect (url_for('editorial'))


@ app.route('/edit_editorial/<id_editorial>')
def get_editorial(id_editorial):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_editorial WHERE id_editorial = '"+id_editorial+"' ")
        dataedit = cursor.fetchall()
    finally:
        return render_template ('edit_editorial.html', editorial=dataedit[0])

@app.route('/update_editoral/<id_editorial>', methods=['POST' , 'GET'] )
def update_editorial(id_editorial):
    cursor = connection.cursor()
    if request.method == 'POST':
        editorial = request.form['editorial']
        direccion = request.form['direccion']
        telefono = request.form['telefono']
        pais = request.form['pais']
        autor = request.form['autor']
        try:
            cursor.execute(" UPDATE t_editorial SET editorial = %s, direccion = %s, telefono = %s, pais = %s, autor = %s WHERE id_editorial = '"+id_editorial+"' ",
                           (editorial, direccion, telefono, pais, autor))
            connection.commit()
        finally:
            flash('Editorial Actualizado')
        return redirect (url_for('editorial'))


@ app.route('/delete_editorial/<string:id_editorial>')
def delete_editorial(id_editorial):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_editorial WHERE id_editorial = '"+id_editorial+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Editorial Borrada')
    return redirect(url_for('editorial'))

@ app.route('/libro_autor')
def libro_autor():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_libro_autor''')
        datalibau = cursor.fetchall()
    finally:
        return render_template('libro_autor.html', t_libro_autor = datalibau) 

@app.route('/add_libro_autor', methods=['POST', 'GET'])
def add_libro_autor():
    cursor = connection.cursor()
    if request.method == 'POST':
        autor = request.form['autor']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute('''INSERT INTO t_libro_autor (autor, titulo_libro)
            VALUES (%s, %s)''',
            (autor, titulo_libro))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('libro_autor'))

@ app.route('/edit_libro_autor/<id_titulolibro>')
def get_libro_autor(id_titulolibro):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_libro_autor WHERE id_titulolibro = '"+id_titulolibro+"' ")
        datala = cursor.fetchall()
    finally:
        return render_template ('edit_libro_autor.html', libroautor=datala[0])

@app.route('/update_libro_autor/<id_titulolibro>', methods=['POST' , 'GET'] )
def update_libro_autor(id_titulolibro):
    cursor = connection.cursor()
    if request.method == 'POST':
        autor = request.form['autor']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute(" UPDATE t_libro_autor SET autor = %s, titulo_libro = %s WHERE id_titulolibro = '"+id_titulolibro+"' ",
                           (autor, titulo_libro))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('libro_autor'))


@ app.route('/delete_libro_autor/<string:id_titulolibro>')
def delete_libro_autor(id_titulolibro):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_libro_autor WHERE id_titulolibro = '"+id_titulolibro+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('libro_autor'))

@ app.route('/estado')
def estado():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_estado''')
        dataestado = cursor.fetchall()
    finally:
        return render_template('estado.html', t_estado = dataestado) #crear archivo html

@app.route('/add_estado', methods=['POST', 'GET'])
def add_estado():
    cursor = connection.cursor()
    if request.method == 'POST':
        descripcion_estado = request.form['descripcion_estado']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute('''INSERT INTO t_estado (descripcion_estado, titulo_libro)
            VALUES (%s, %s)''',
            (descripcion_estado, titulo_libro))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('estado'))

@ app.route('/edit_estado/<id_estado>')
def get_estado(id_estado):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_estado WHERE id_estado = '"+id_estado+"' ")
        dataes = cursor.fetchall()
    finally:
        return render_template ('edit_estado.html', estado=dataes[0])

@app.route('/update_estado/<id_estado>', methods=['POST' , 'GET'] )
def update_estado(id_estado):
    cursor = connection.cursor()
    if request.method == 'POST':
        descripcion_estado = request.form['descripcion_estado']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute(" UPDATE t_estado SET descripcion_estado = %s, titulo_libro = %s WHERE id_estado = '"+id_estado+"' ",
                           (descripcion_estado, titulo_libro))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('estado'))


@ app.route('/delete_estado/<string:id_estado>')
def delete_estado(id_estado):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_estado WHERE id_estado = '"+id_estado+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('estado'))

@ app.route('/sucursal')
def sucursal():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_sucursal''')
        datasur = cursor.fetchall()
    finally:
        return render_template('sucursal.html', t_sucursal = datasur) #crear archivo html

@app.route('/add_sucursal', methods=['POST', 'GET'])
def add_sucursal():
    cursor = connection.cursor()
    if request.method == 'POST':
        sucursal = request.form['sucursal']
        titulo_libro = request.form['titulo_libro']
        direccion = request.form['direccion']
        try:
            cursor.execute('''INSERT INTO t_sucursal (sucursal, titulo_libro, direccion)
            VALUES (%s, %s, %s)''',
            (sucursal, titulo_libro,direccion))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('sucursal'))

@ app.route('/edit_sucursal/<id_sucursal>')
def get_sucursal(id_sucursal):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_sucursal WHERE id_sucursal = '"+id_sucursal+"' ")
        datasurcursal = cursor.fetchall()
    finally:
        return render_template ('edit_sucursal.html', sucursal=datasurcursal[0])

@app.route('/update_sucursal/<id_sucursal>', methods=['POST' , 'GET'] )
def update_sucursal(id_sucursal):
    cursor = connection.cursor()
    if request.method == 'POST':
        sucursal = request.form['sucursal']
        titulo_libro = request.form['titulo_libro']
        direccion = request.form['direccion']
        try:
            cursor.execute(" UPDATE t_sucursal SET sucursal = %s, titulo_libro = %s, direccion = %s WHERE id_sucursal = '"+id_sucursal+"' ",
                           (sucursal, titulo_libro, direccion))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('sucursal'))


@ app.route('/delete_sucursal/<string:id_sucursal>')
def delete_sucursal(id_sucursal):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_sucursal WHERE id_sucursal = '"+id_sucursal+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('sucursal'))

@ app.route('/area_estudio')
def area_estudio():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_area_estudio''')
        dataareaes = cursor.fetchall()
    finally:
        return render_template('area.html', t_area_estudio = dataareaes) #crear archivo html

@app.route('/add_area', methods=['POST', 'GET'])
def add_area_estudio():
    cursor = connection.cursor()
    if request.method == 'POST':
        area_estudio = request.form['area_estudio']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute('''INSERT INTO t_area_estudio (area_estudio, titulo_libro)
            VALUES (%s, %s)''',
            (area_estudio, titulo_libro))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('area_estudio'))

@ app.route('/edit_area/<id_area>')
def get_area(id_area):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_area_estudio WHERE id_area = '"+id_area+"' ")
        dataarea = cursor.fetchall()
    finally:
        return render_template ('edit_area.html', area=dataarea[0])

@app.route('/update_area/<id_area>', methods=['POST' , 'GET'] )
def update_area(id_area):
    cursor = connection.cursor()
    if request.method == 'POST':
        area_estudio = request.form['area_estudio']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute(" UPDATE t_area_estudio SET area_estudio = %s, titulo_libro = %s WHERE id_area = '"+id_area+"' ",
                           (area_estudio, titulo_libro))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('area_estudio'))


@ app.route('/delete_area/<string:id_area>')
def delete_area(id_area):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_area_estudio WHERE id_area = '"+id_area+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('area_estudio'))

@ app.route('/autor')
def autor():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_autor''')
        dataautor = cursor.fetchall()
    finally:
        return render_template('autor.html', t_autor = dataautor) #crear archivo html

@app.route('/add_autor', methods=['POST', 'GET'])
def add_autor():
    cursor = connection.cursor()
    if request.method == 'POST':
        titulo_libro = request.form['titulo_libro']
        autor = request.form['autor']
        try:
            cursor.execute('''INSERT INTO t_autor (titulo_libro, autor)
            VALUES (%s, %s)''',
            (titulo_libro, autor))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('autor'))

@ app.route('/edit_autor/<id_autor>')
def get_autor(id_autor):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_autor WHERE id_autor = '"+id_autor+"' ")
        datautor = cursor.fetchall()
    finally:
        return render_template ('edit_autor.html', autor=datautor[0])

@app.route('/update_autor/<id_autor>', methods=['POST' , 'GET'] )
def update_autor(id_autor):
    cursor = connection.cursor()
    if request.method == 'POST':
        titulo_libro = request.form['titulo_libro']
        autor = request.form['autor']
        try:
            cursor.execute(" UPDATE t_autor SET titulo_libro = %s, autor = %s WHERE id_autor = '"+id_autor+"' ",
                           (titulo_libro, autor))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('autor'))

@ app.route('/delete_autor/<string:id_autor>')
def delete_autor(id_autor):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_autor WHERE id_autor = '"+id_autor+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('autor'))

@ app.route('/tipo_prestamo')
def tipo_prestamo():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_tipo_prestamo''')
        datatp = cursor.fetchall()
    finally:
        return render_template('tipop.html', t_tipo_prestamo = datatp) #crear archivo html

@app.route('/add_tipop', methods=['POST', 'GET'])
def add_tipop():
    cursor = connection.cursor()
    if request.method == 'POST':
        tipo_prestamo = request.form['tipo_prestamo']
        titulo_libro = request.form['titulo_libro']
        fecha_prestamo = request.form['fecha_prestamo']
        fecha_devolucion = request.form['fecha_devolucion']
        hora = request.form['hora']
        try:
            cursor.execute('''INSERT INTO t_tipo_prestamo (tipo_prestamo, titulo_libro, fecha_prestamo, fecha_devolucion, hora)
            VALUES (%s, %s, %s, %s, %s)''',
            (tipo_prestamo, titulo_libro, fecha_prestamo, fecha_devolucion, hora ))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('tipo_prestamo'))

@ app.route('/edit_tipop/<id_t_prestamo>')
def get_tipop(id_t_prestamo):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_tipo_prestamo WHERE id_t_prestamo = '"+id_t_prestamo+"' ")
        datatipop = cursor.fetchall()
    finally:
        return render_template ('edit_tipop.html', tipo=datatipop[0])

@app.route('/update_tipop/<id_t_prestamo>', methods=['POST' , 'GET'] )
def update_tipop(id_t_prestamo):
    cursor = connection.cursor()
    if request.method == 'POST':
        tipo_prestamo = request.form['tipo_prestamo']
        titulo_libro = request.form['titulo_libro']
        fecha_prestamo = request.form['fecha_prestamo']
        fecha_devolucion = request.form['fecha_devolucion']
        hora = request.form['hora']
        try:
            cursor.execute(" UPDATE t_tipo_prestamo SET tipo_prestamo = %s, titulo_libro = %s, fecha_prestamo = %s, fecha_devolucion = %s, hora = %s  WHERE id_t_prestamo = '"+id_t_prestamo+"' ",
                           (tipo_prestamo, titulo_libro, fecha_prestamo, fecha_devolucion, hora ))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('tipo_prestamo'))


@ app.route('/delete_tipop/<string:id_t_prestamo>')
def delete_tipop(id_t_prestamo):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_tipo_prestamo WHERE id_t_prestamo = '"+id_t_prestamo+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('tipo_prestamo'))

@ app.route('/pais')
def pais():
    cursor = connection.cursor()
    try:
        cursor.execute(''' SELECT * FROM t_pais''')
        datapa = cursor.fetchall()
    finally:
        return render_template('pais.html', t_pais = datapa) #crear archivo html

@app.route('/add_pais', methods=['POST', 'GET'])
def add_pais():
    cursor = connection.cursor()
    if request.method == 'POST':
        pais = request.form['pais']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute('''INSERT INTO t_pais (pais, titulo_libro)
            VALUES (%s, %s)''',
            (pais, titulo_libro ))
            connection.commit()
        finally:
            flash('Registrado')
            return redirect (url_for('pais'))

@ app.route('/edit_pais/<id_pais>')
def get_pais(id_pais):
    cursor = connection.cursor()
    try:
        cursor.execute(
            " SELECT * FROM t_pais WHERE id_pais = '"+id_pais+"' ")
        datapais = cursor.fetchall()
    finally:
        return render_template ('edit_pais.html', pais=datapais[0])

@app.route('/update_pais/<id_pais>', methods=['POST' , 'GET'] )
def update_pais(id_pais):
    cursor = connection.cursor()
    if request.method == 'POST':
        pais = request.form['pais']
        titulo_libro = request.form['titulo_libro']
        try:
            cursor.execute(" UPDATE t_pais SET pais = %s, titulo_libro = %s  WHERE id_pais = '"+id_pais+"' ",
                           (pais, titulo_libro))
            connection.commit()
        finally:
            flash('Actualizado')
        return redirect (url_for('pais'))


@ app.route('/delete_pais/<string:id_pais>')
def delete_pais(id_pais):
    cursor = connection.cursor()
    borrar = "DELETE FROM t_pais WHERE id_pais = '"+id_pais+"' "
    try:
        cursor.execute(borrar)
        connection.commit()
    finally:
        flash('Borrado')
    return redirect(url_for('pais'))

#MODIFICAR TODAS LA LLAVES FORANEAS(NO SE REPITEN), PARA VOLVER A RELACIONAR LAS TABLAS 

if __name__ == '__main__':
    app.run(port=5000, debug=True)
