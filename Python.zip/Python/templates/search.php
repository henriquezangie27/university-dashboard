<?php 
			// Connection info. file
            include 'config.php';	
?>
<?php
 $aKeyword = explode(" ", $_POST['keywords']);
 $query ="SELECT * FROM t_autor WHERE titulo_libro like '%" . $aKeyword[0] . "%' OR autor like '%" . $aKeyword[0] . "%'";
 
for($i = 1; $i < count($aKeyword); $i++) {
   if(!empty($aKeyword[$i])) {
       $query .= " OR descripcion like '%" . $aKeyword[$i] . "%'";
   }
}
?>